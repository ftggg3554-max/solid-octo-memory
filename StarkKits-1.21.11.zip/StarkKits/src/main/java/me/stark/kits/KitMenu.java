package me.stark.kits;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;

public class KitMenu implements InventoryHolder {

    public static final int SIZE = 45; // 5 rows

    private final StarkKits plugin;
    private final Inventory inventory;
    private final Map<Integer, Kit> slots = new HashMap<>();

    public KitMenu(StarkKits plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, SIZE,
                StarkKits.color(plugin.getConfig().getString("menu-title", "&8Kits")));
    }

    public void render(Player player) {
        slots.clear();

        Material fillerMat = Material.matchMaterial(plugin.getConfig().getString("filler", "GRAY_STAINED_GLASS_PANE"));
        if (fillerMat == null) fillerMat = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack filler = new ItemStack(fillerMat);
        ItemMeta fm = filler.getItemMeta();
        fm.displayName(Component.text(" "));
        filler.setItemMeta(fm);

        for (int i = 0; i < SIZE; i++) inventory.setItem(i, filler);

        for (Kit kit : plugin.getKits()) {
            if (kit.slot < 0 || kit.slot >= SIZE) continue;
            inventory.setItem(kit.slot, plugin.buildIcon(player, kit));
            slots.put(kit.slot, kit);
        }
    }

    public Kit kitAt(int slot) {
        return slots.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
