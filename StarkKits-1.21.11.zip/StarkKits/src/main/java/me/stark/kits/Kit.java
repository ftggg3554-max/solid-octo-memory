package me.stark.kits;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;

public class Kit {

    public final String key;
    public String displayName;
    public Material icon = Material.CHEST;
    public int slot;
    public String permission;
    public long cooldown; // seconds
    public boolean clearInventory = false; // wipe inventory/armor/offhand before giving
    public boolean autoGive; // give on join (empty inventory) and on respawn
    /** key = inventory slot ("0".."35") or boots/leggings/chestplate/helmet/offhand */
    public final Map<String, ItemStack> items = new LinkedHashMap<>();

    public Kit(String key) {
        this.key = key;
    }
}
