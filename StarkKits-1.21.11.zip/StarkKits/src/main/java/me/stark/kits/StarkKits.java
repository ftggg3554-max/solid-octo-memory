package me.stark.kits;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StarkKits extends JavaPlugin implements TabExecutor, Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();
    private static final String PREFIX = "&8[&6Kits&8] ";

    /** EssentialsX-style (old Bukkit) enchant names -> modern keys */
    private static final Map<String, String> LEGACY_ENCHANTS = new HashMap<>();

    static {
        LEGACY_ENCHANTS.put("damage_all", "sharpness");
        LEGACY_ENCHANTS.put("damage_undead", "smite");
        LEGACY_ENCHANTS.put("damage_arthropods", "bane_of_arthropods");
        LEGACY_ENCHANTS.put("protection_environmental", "protection");
        LEGACY_ENCHANTS.put("protection_fire", "fire_protection");
        LEGACY_ENCHANTS.put("protection_explosions", "blast_protection");
        LEGACY_ENCHANTS.put("protection_projectile", "projectile_protection");
        LEGACY_ENCHANTS.put("protection_fall", "feather_falling");
        LEGACY_ENCHANTS.put("oxygen", "respiration");
        LEGACY_ENCHANTS.put("water_worker", "aqua_affinity");
        LEGACY_ENCHANTS.put("dig_speed", "efficiency");
        LEGACY_ENCHANTS.put("durability", "unbreaking");
        LEGACY_ENCHANTS.put("loot_bonus_mobs", "looting");
        LEGACY_ENCHANTS.put("loot_bonus_blocks", "fortune");
        LEGACY_ENCHANTS.put("arrow_damage", "power");
        LEGACY_ENCHANTS.put("arrow_knockback", "punch");
        LEGACY_ENCHANTS.put("arrow_fire", "flame");
        LEGACY_ENCHANTS.put("arrow_infinite", "infinity");
        LEGACY_ENCHANTS.put("luck", "luck_of_the_sea");
    }

    private final Map<String, Kit> kits = new LinkedHashMap<>();
    private File kitsFile;
    private YamlConfiguration kitsConfig;

    // cooldown storage: DB thread + in-memory cache (main thread only reads the cache)
    private Database db;
    private ExecutorService dbExecutor;
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        kitsFile = new File(getDataFolder(), "kits.yml");
        if (!kitsFile.exists()) saveResource("kits.yml", false);

        db = new Database(this);
        try {
            db.init();
        } catch (SQLException e) {
            getLogger().severe("Could not open the database (" + (db.isMysql() ? "mysql" : "sqlite") + "): " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        dbExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, "StarkKits-DB"));

        migrateOldData();
        dbExecutor.execute(db::purgeExpired);

        loadKits();

        getCommand("kit").setExecutor(this);
        getCommand("kit").setTabCompleter(this);
        getCommand("savekit").setExecutor(this);
        getCommand("savekit").setTabCompleter(this);
        getCommand("updatekit").setExecutor(this);
        getCommand("updatekit").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);

        for (Player p : Bukkit.getOnlinePlayers()) loadPlayerAsync(p.getUniqueId());
    }

    @Override
    public void onDisable() {
        if (dbExecutor != null) {
            dbExecutor.shutdown();
            try {
                dbExecutor.awaitTermination(5, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        if (db != null) db.close();
    }

    /** Imports the cooldowns of the old yml storage (data.yml) once, then renames it. */
    private void migrateOldData() {
        File old = new File(getDataFolder(), "data.yml");
        if (!old.exists()) return;

        YamlConfiguration y = YamlConfiguration.loadConfiguration(old);
        ConfigurationSection players = y.getConfigurationSection("players");
        long now = System.currentTimeMillis();
        List<Object[]> rows = new ArrayList<>();
        if (players != null) {
            for (String id : players.getKeys(false)) {
                ConfigurationSection kitSec = players.getConfigurationSection(id);
                if (kitSec == null) continue;
                try {
                    UUID uuid = UUID.fromString(id);
                    for (String kit : kitSec.getKeys(false)) {
                        long exp = kitSec.getLong(kit);
                        if (exp > now) rows.add(new Object[]{uuid, kit, exp});
                    }
                } catch (IllegalArgumentException ignored) {
                    // not a uuid
                }
            }
        }
        dbExecutor.execute(() -> {
            for (Object[] r : rows) db.save((UUID) r[0], (String) r[1], (Long) r[2]);
        });
        if (old.renameTo(new File(getDataFolder(), "data.yml.migrated"))) {
            getLogger().info("Imported " + rows.size() + " cooldowns from data.yml into the database.");
        }
    }

    private void loadPlayerAsync(UUID uuid) {
        dbExecutor.execute(() -> {
            Map<String, Long> loaded = db.loadPlayer(uuid);
            if (Bukkit.getPlayer(uuid) != null) cooldowns.put(uuid, loaded);
        });
    }

    // ------------------------------------------------------------------ loading

    private void loadKits() {
        kits.clear();
        kitsConfig = YamlConfiguration.loadConfiguration(kitsFile);
        ConfigurationSection root = kitsConfig.getConfigurationSection("kits");
        if (root == null) return;

        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;

            Kit kit = new Kit(key);
            kit.displayName = s.getString("display-name", "&f" + key.toUpperCase(Locale.ROOT));
            Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
            kit.icon = icon != null ? icon : Material.CHEST;
            kit.slot = s.getInt("slot", 0);
            kit.permission = s.getString("permission", "kits." + key.toLowerCase(Locale.ROOT));
            kit.cooldown = s.getLong("cooldown", 0);
            kit.autoGive = s.getBoolean("auto-give", false);
            kit.clearInventory = s.getBoolean("clear-inventory", false);

            ConfigurationSection items = s.getConfigurationSection("items");
            if (items != null) {
                for (String slot : items.getKeys(false)) {
                    ItemStack item = decode(items.getString(slot, ""));
                    if (item == null) {
                        getLogger().warning("Could not read item '" + slot + "' of kit " + key);
                        continue;
                    }
                    kit.items.put(slot, item);
                }
            }

            if (kit.items.isEmpty()) {
                int next = 0;
                for (String line : s.getStringList("text-items")) {
                    ItemStack item = parseTextItem(line);
                    if (item == null) {
                        getLogger().warning("Could not read text item '" + line + "' of kit " + key);
                        continue;
                    }
                    String slotKey = armorKey(item.getType());
                    if (slotKey == null || kit.items.containsKey(slotKey)) {
                        while (kit.items.containsKey(String.valueOf(next))) next++;
                        slotKey = String.valueOf(next++);
                    }
                    kit.items.put(slotKey, item);
                }
            }

            if (kit.slot < 0 || kit.slot >= KitMenu.SIZE) {
                getLogger().warning("Kit " + key + " has an invalid slot (" + kit.slot + "), it will not show in the menu.");
            }

            if (Bukkit.getPluginManager().getPermission(kit.permission) == null) {
                Bukkit.getPluginManager().addPermission(new Permission(kit.permission, PermissionDefault.OP));
            }

            kits.put(key.toLowerCase(Locale.ROOT), kit);
        }
    }

    public Collection<Kit> getKits() {
        return kits.values();
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("savekit")) return handleSave(sender, args, false);
        if (name.equals("updatekit")) return handleSave(sender, args, true);

        if (args.length >= 1 && args[0].equalsIgnoreCase("seticon")) {
            handleSetIcon(sender, args);
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("kits.admin")) {
                msg(sender, "&cYou don't have permission to do that.");
                return true;
            }
            reloadConfig();
            loadKits();
            msg(sender, "&aReloaded &f" + kits.size() + " &akits.");
            return true;
        }

        if (!(sender instanceof Player p)) {
            msg(sender, "&cOnly players can open the kits menu.");
            return true;
        }
        KitMenu menu = new KitMenu(this);
        menu.render(p);
        p.openInventory(menu.getInventory());
        return true;
    }

    private void handleSetIcon(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            msg(sender, "&cOnly players can do that.");
            return;
        }
        if (!player.hasPermission("kits.admin")) {
            msg(player, "&cYou don't have permission to do that.");
            return;
        }
        if (args.length < 2) {
            msg(player, "&cUsage: &f/kit seticon <kit> &7(hold the item you want as the icon)");
            return;
        }
        Kit kit = kits.get(args[1].toLowerCase(Locale.ROOT));
        if (kit == null) {
            msg(player, "&cUnknown kit. Available: &f" + String.join(", ", kits.keySet()));
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (isEmpty(hand)) {
            msg(player, "&cHold an item in your main hand first.");
            return;
        }
        kit.icon = hand.getType();
        kitsConfig.set("kits." + kit.key + ".icon", hand.getType().name());
        try {
            kitsConfig.save(kitsFile);
        } catch (IOException ex) {
            msg(player, "&cCould not save kits.yml: " + ex.getMessage());
            return;
        }
        msg(player, "&aThe icon of the " + kit.displayName + " &akit is now &f" + hand.getType().name() + "&a.");
    }

    /**
     * /savekit <kit> [time]  - replaces the kit items with your inventory and optionally sets the cooldown.
     * /updatekit <kit>       - replaces the kit items with your inventory, keeps everything else.
     */
    private boolean handleSave(CommandSender sender, String[] args, boolean update) {
        if (!(sender instanceof Player p)) {
            msg(sender, "&cOnly players can save kits.");
            return true;
        }
        if (!p.hasPermission("kits.admin")) {
            msg(p, "&cYou don't have permission to do that.");
            return true;
        }
        if (args.length < 1) {
            if (update) {
                msg(p, "&cUsage: &f/updatekit <kit> &7(replaces the kit items with your inventory)");
            } else {
                msg(p, "&cUsage: &f/savekit <kit> [time]");
                msg(p, "&7Time examples: &f30s&7, &f10m&7, &f12h&7, &f5d&7, &f1d12h");
            }
            return true;
        }

        Kit kit = kits.get(args[0].toLowerCase(Locale.ROOT));
        if (kit == null) {
            msg(p, "&cUnknown kit. Available: &f" + String.join(", ", kits.keySet()));
            return true;
        }

        long cooldown = kit.cooldown;
        if (!update && args.length >= 2) {
            cooldown = parseDuration(args[1]);
            if (cooldown < 0) {
                msg(p, "&cInvalid time. Use d (days), h (hours), m (minutes), s (seconds). Example: &f5d &cor &f1d12h30m");
                return true;
            }
        }

        PlayerInventory inv = p.getInventory();
        Map<String, ItemStack> snapshot = new LinkedHashMap<>();
        for (int i = 0; i < 36; i++) put(snapshot, String.valueOf(i), inv.getItem(i));
        put(snapshot, "boots", inv.getBoots());
        put(snapshot, "leggings", inv.getLeggings());
        put(snapshot, "chestplate", inv.getChestplate());
        put(snapshot, "helmet", inv.getHelmet());
        put(snapshot, "offhand", inv.getItemInOffHand());

        if (snapshot.isEmpty()) {
            msg(p, "&cYour inventory is empty.");
            return true;
        }

        String path = "kits." + kit.key;
        kitsConfig.set(path + ".items", null);
        kitsConfig.set(path + ".text-items", null);
        for (Map.Entry<String, ItemStack> e : snapshot.entrySet()) {
            kitsConfig.set(path + ".items." + e.getKey(), encode(e.getValue()));
        }
        kitsConfig.set(path + ".cooldown", cooldown);
        try {
            kitsConfig.save(kitsFile);
        } catch (IOException ex) {
            msg(p, "&cCould not save kits.yml: " + ex.getMessage());
            return true;
        }

        kit.items.clear();
        kit.items.putAll(snapshot);
        kit.cooldown = cooldown;

        msg(p, "&a" + (update ? "Updated" : "Saved") + " the " + kit.displayName + " &akit with &f"
                + snapshot.size() + " &aitems. Cooldown: &f" + formatDuration(cooldown));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("savekit") || name.equals("updatekit")) {
            if (!sender.hasPermission("kits.admin")) return List.of();
            if (args.length == 1) return filter(new ArrayList<>(kits.keySet()), args[0]);
            if (args.length == 2 && name.equals("savekit")) return filter(List.of("30s", "10m", "1h", "1d", "5d"), args[1]);
            return List.of();
        }
        if (sender.hasPermission("kits.admin")) {
            if (args.length == 1) return filter(List.of("reload", "seticon"), args[0]);
            if (args.length == 2 && args[0].equalsIgnoreCase("seticon")) {
                return filter(new ArrayList<>(kits.keySet()), args[1]);
            }
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.startsWith(p)).toList();
    }

    // ------------------------------------------------------------------ menu

    public ItemStack buildIcon(Player player, Kit kit) {
        ItemStack item = new ItemStack(kit.icon);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(color(kit.displayName));

        List<Component> lore = new ArrayList<>();
        lore.add(color("&8&m                              "));
        lore.add(color("&7Kit: " + kit.displayName));
        lore.add(color("&7Cooldown: &f" + formatDuration(kit.cooldown)));
        lore.add(Component.empty());
        if (kit.clearInventory) lore.add(color("&c! &7Claiming clears your inventory"));
        lore.add(color(status(player, kit)));
        lore.add(color("&8&m                              "));
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }

    private String status(Player p, Kit kit) {
        if (!p.hasPermission(kit.permission)) return "&c&lLOCKED &7- you don't have access";
        if (kit.items.isEmpty()) return "&cThis kit is empty";
        if (!p.hasPermission("kits.bypass")) {
            if (!cooldowns.containsKey(p.getUniqueId())) return "&7Loading your data...";
            long left = remaining(p, kit);
            if (left > 0) return "&cOn cooldown: &f" + formatDuration((left + 999) / 1000);
        }
        return "&a&lCLICK &7to claim this kit";
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof KitMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getRawSlot() < 0 || e.getRawSlot() >= e.getInventory().getSize()) return;

        Kit kit = menu.kitAt(e.getRawSlot());
        if (kit == null) return;
        claim(p, kit, menu);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof KitMenu) e.setCancelled(true);
    }

    private void claim(Player p, Kit kit, KitMenu menu) {
        if (!p.hasPermission(kit.permission)) {
            msg(p, "&cYou don't have permission to claim the " + kit.displayName + " &ckit.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        if (kit.items.isEmpty()) {
            msg(p, "&cThis kit is empty.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        boolean bypass = p.hasPermission("kits.bypass");
        if (!bypass) {
            if (!cooldowns.containsKey(p.getUniqueId())) {
                msg(p, "&cYour data is still loading, try again in a moment.");
                return;
            }
            long left = remaining(p, kit);
            if (left > 0) {
                msg(p, "&cYou can claim the " + kit.displayName + " &ckit again in &f" + formatDuration((left + 999) / 1000) + "&c.");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
        }

        give(p, kit, kit.clearInventory);

        if (!bypass && kit.cooldown > 0) {
            UUID uuid = p.getUniqueId();
            String kitKey = kit.key.toLowerCase(Locale.ROOT);
            long expires = System.currentTimeMillis() + kit.cooldown * 1000L;
            cooldowns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put(kitKey, expires);
            dbExecutor.execute(() -> db.save(uuid, kitKey, expires));
        }

        msg(p, "&aYou claimed the " + kit.displayName + " &akit!");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        menu.render(p);
    }

    private static void wipe(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(new ItemStack(Material.AIR));
    }

    private void give(Player p, Kit kit, boolean clear) {
        if (clear) wipe(p);
        PlayerInventory inv = p.getInventory();
        for (Map.Entry<String, ItemStack> e : kit.items.entrySet()) {
            ItemStack item = e.getValue().clone();
            switch (e.getKey()) {
                case "helmet" -> {
                    if (isEmpty(inv.getHelmet())) inv.setHelmet(item); else addOrDrop(p, item);
                }
                case "chestplate" -> {
                    if (isEmpty(inv.getChestplate())) inv.setChestplate(item); else addOrDrop(p, item);
                }
                case "leggings" -> {
                    if (isEmpty(inv.getLeggings())) inv.setLeggings(item); else addOrDrop(p, item);
                }
                case "boots" -> {
                    if (isEmpty(inv.getBoots())) inv.setBoots(item); else addOrDrop(p, item);
                }
                case "offhand" -> {
                    if (isEmpty(inv.getItemInOffHand())) inv.setItemInOffHand(item); else addOrDrop(p, item);
                }
                default -> {
                    int slot = parseSlot(e.getKey());
                    if (slot >= 0 && slot < 36 && isEmpty(inv.getItem(slot))) inv.setItem(slot, item);
                    else addOrDrop(p, item);
                }
            }
        }
    }

    private void addOrDrop(Player p, ItemStack item) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(item);
        for (ItemStack rest : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
    }

    // ------------------------------------------------------------------ player events / auto give

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        loadPlayerAsync(p.getUniqueId());
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && isInventoryEmpty(p)) giveAutoKits(p);
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        cooldowns.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) giveAutoKits(p);
        }, 2L);
    }

    private void giveAutoKits(Player p) {
        for (Kit kit : kits.values()) {
            if (!kit.autoGive || kit.items.isEmpty()) continue;
            give(p, kit, false);
            msg(p, "&aYou received the " + kit.displayName + " &akit.");
        }
    }

    private static boolean isInventoryEmpty(Player p) {
        PlayerInventory inv = p.getInventory();
        for (ItemStack it : inv.getStorageContents()) if (!isEmpty(it)) return false;
        for (ItemStack it : inv.getArmorContents()) if (!isEmpty(it)) return false;
        return isEmpty(inv.getItemInOffHand());
    }

    // ------------------------------------------------------------------ helpers

    private long remaining(Player p, Kit kit) {
        Map<String, Long> m = cooldowns.get(p.getUniqueId());
        if (m == null) return 0L;
        return m.getOrDefault(kit.key.toLowerCase(Locale.ROOT), 0L) - System.currentTimeMillis();
    }

    private static String armorKey(Material m) {
        String n = m.name();
        if (n.endsWith("_HELMET")) return "helmet";
        if (n.endsWith("_CHESTPLATE")) return "chestplate";
        if (n.endsWith("_LEGGINGS")) return "leggings";
        if (n.endsWith("_BOOTS")) return "boots";
        return null;
    }

    /** Parses one EssentialsX-style line, e.g. "stone_sword 1 name:&7Sword vanishing_curse:1 unbreakable" */
    private ItemStack parseTextItem(String line) {
        String[] t = line.trim().split("\\s+");
        if (t.length == 0 || t[0].isEmpty()) return null;
        Material mat = Material.matchMaterial(t[0]);
        if (mat == null || !mat.isItem()) return null;

        int amount = 1;
        int from = 1;
        if (t.length > 1 && t[1].matches("\\d{1,3}")) {
            amount = Math.max(1, Math.min(Integer.parseInt(t[1]), mat.getMaxStackSize()));
            from = 2;
        }

        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        for (int i = from; i < t.length; i++) {
            String tok = t[i];
            String low = tok.toLowerCase(Locale.ROOT);

            if (low.equals("unbreakable")) {
                meta.setUnbreakable(true);
            } else if (low.startsWith("name:")) {
                meta.displayName(color(tok.substring(5).replace('_', ' ')));
            } else if (low.startsWith("lore:")) {
                List<Component> lore = new ArrayList<>();
                for (String part : tok.substring(5).split("\\|")) lore.add(color(part.replace('_', ' ')));
                meta.lore(lore);
            } else if (low.startsWith("color:") && meta instanceof LeatherArmorMeta lm) {
                try {
                    lm.setColor(Color.fromRGB(Integer.parseInt(low.substring(6))));
                } catch (Exception ignored) {
                    // bad color, skip
                }
            } else {
                int idx = low.indexOf(':');
                if (idx <= 0) continue;
                String ench = low.substring(0, idx);
                try {
                    int level = Integer.parseInt(low.substring(idx + 1));
                    String key = LEGACY_ENCHANTS.getOrDefault(ench, ench);
                    Enchantment e = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(key));
                    if (e != null) meta.addEnchant(e, level, true);
                } catch (Exception ignored) {
                    // unknown enchant, skip
                }
            }
        }

        item.setItemMeta(meta);
        return item;
    }

    private static boolean isEmpty(ItemStack item) {
        return item == null || item.getType().isAir();
    }

    private static void put(Map<String, ItemStack> map, String key, ItemStack item) {
        if (!isEmpty(item)) map.put(key, item.clone());
    }

    private static int parseSlot(String key) {
        try {
            return Integer.parseInt(key);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String encode(ItemStack item) {
        return Base64.getEncoder().encodeToString(item.serializeAsBytes());
    }

    private static ItemStack decode(String b64) {
        try {
            return ItemStack.deserializeBytes(Base64.getDecoder().decode(b64));
        } catch (Exception e) {
            return null;
        }
    }

    /** @return seconds, or -1 if invalid */
    static long parseDuration(String input) {
        String s = input.toLowerCase(Locale.ROOT);
        try {
            if (s.matches("\\d{1,9}")) return Long.parseLong(s);
            if (!s.matches("(\\d{1,9}[dhms])+")) return -1;
            Matcher m = Pattern.compile("(\\d{1,9})([dhms])").matcher(s);
            long total = 0;
            while (m.find()) {
                long v = Long.parseLong(m.group(1));
                switch (m.group(2).charAt(0)) {
                    case 'd' -> total += v * 86400L;
                    case 'h' -> total += v * 3600L;
                    case 'm' -> total += v * 60L;
                    default -> total += v;
                }
            }
            return total;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    static String formatDuration(long seconds) {
        if (seconds <= 0) return "None";
        long d = seconds / 86400;
        long h = (seconds % 86400) / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0) sb.append(s).append("s ");
        return sb.toString().trim();
    }

    public static Component color(String text) {
        return LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false);
    }

    private void msg(CommandSender sender, String text) {
        sender.sendMessage(color(PREFIX + text));
    }
}
