package me.stark.kits;

import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Cooldown storage. SQLite (default) or MySQL, chosen in config.yml.
 * All methods block, so they must be called from the DB thread, never the main thread.
 */
public class Database {

    private final StarkKits plugin;
    private final boolean mysql;
    private Connection connection;

    public Database(StarkKits plugin) {
        this.plugin = plugin;
        this.mysql = plugin.getConfig().getString("storage.type", "sqlite").equalsIgnoreCase("mysql");
    }

    public boolean isMysql() {
        return mysql;
    }

    private Connection open() throws SQLException {
        try {
            if (mysql) {
                FileConfiguration c = plugin.getConfig();
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url = "jdbc:mysql://" + c.getString("storage.mysql.host", "localhost")
                        + ":" + c.getInt("storage.mysql.port", 3306)
                        + "/" + c.getString("storage.mysql.database", "starkkits")
                        + "?useSSL=false&autoReconnect=true&characterEncoding=utf8";
                return DriverManager.getConnection(url,
                        c.getString("storage.mysql.user", "root"),
                        c.getString("storage.mysql.password", ""));
            }
            Class.forName("org.sqlite.JDBC");
            File file = new File(plugin.getDataFolder(), "kits.db");
            return DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC driver not found: " + e.getMessage(), e);
        }
    }

    private synchronized Connection conn() throws SQLException {
        if (connection == null || connection.isClosed() || !connection.isValid(2)) {
            connection = open();
        }
        return connection;
    }

    public synchronized void init() throws SQLException {
        try (Statement st = conn().createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS kit_cooldowns ("
                    + "uuid VARCHAR(36) NOT NULL, "
                    + "kit VARCHAR(64) NOT NULL, "
                    + "expires BIGINT NOT NULL, "
                    + "PRIMARY KEY (uuid, kit))");
        }
    }

    /** @return kit key -> expiry (epoch millis), only entries still running */
    public synchronized Map<String, Long> loadPlayer(UUID uuid) {
        Map<String, Long> result = new ConcurrentHashMap<>();
        try (PreparedStatement ps = conn().prepareStatement("SELECT kit, expires FROM kit_cooldowns WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                long now = System.currentTimeMillis();
                while (rs.next()) {
                    long exp = rs.getLong("expires");
                    if (exp > now) result.put(rs.getString("kit"), exp);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Could not load cooldowns of " + uuid, e);
        }
        return result;
    }

    public synchronized void save(UUID uuid, String kit, long expires) {
        // REPLACE INTO works on both SQLite and MySQL
        try (PreparedStatement ps = conn().prepareStatement("REPLACE INTO kit_cooldowns (uuid, kit, expires) VALUES (?, ?, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, kit);
            ps.setLong(3, expires);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save cooldown of " + uuid, e);
        }
    }

    public synchronized void purgeExpired() {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM kit_cooldowns WHERE expires < ?")) {
            ps.setLong(1, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Could not purge expired cooldowns", e);
        }
    }

    public synchronized void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException ignored) {
            // closing anyway
        }
    }
}
